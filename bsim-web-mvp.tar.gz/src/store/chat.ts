import { create } from 'zustand'
import type { Conversation, Message, WsNewMessagePayload, WsMessageAckPayload } from '../types'
import { conversationsApi, messagesApi } from '../services/api'
import { wsService } from '../services/ws'

interface ChatState {
  conversations: Conversation[]
  activeConversationId: string | null
  messagesByConv: Record<string, Message[]>
  isLoadingConversations: boolean
  isLoadingMessages: boolean
  loadConversations: () => Promise<void>
  openConversation: (id: string) => Promise<void>
  sendMessage: (content: string) => Promise<void>
  wireWsListeners: () => void
}

function genClientMsgId() {
  return `web-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`
}

export const useChatStore = create<ChatState>((set, get) => ({
  conversations: [],
  activeConversationId: null,
  messagesByConv: {},
  isLoadingConversations: false,
  isLoadingMessages: false,

  loadConversations: async () => {
    set({ isLoadingConversations: true })
    try {
      const { data } = await conversationsApi.list()
      set({ conversations: data.conversations, isLoadingConversations: false })
    } catch {
      set({ isLoadingConversations: false })
    }
  },

  openConversation: async (id: string) => {
    set({ activeConversationId: id, isLoadingMessages: true })
    try {
      const { data } = await messagesApi.list(id)
      set((state) => ({
        messagesByConv: { ...state.messagesByConv, [id]: data.messages },
        isLoadingMessages: false,
      }))
      const seq = data.messages[data.messages.length - 1]?.seq
      if (seq !== undefined) wsService.markRead(id, seq)
    } catch {
      set({ isLoadingMessages: false })
    }
  },

  sendMessage: async (content: string) => {
    const { activeConversationId } = get()
    if (!activeConversationId || !content.trim()) return
    const clientMsgId = genClientMsgId()

    // Optimistic append — tampil dulu, diganti/dikonfirmasi via WS ack atau
    // response REST (mana yang datang duluan tidak masalah, id akhirnya sama).
    const optimistic: Message = {
      id: clientMsgId,
      conversationId: activeConversationId,
      senderId: 'me',
      clientMsgId,
      type: 'TEXT',
      content,
      createdAt: new Date().toISOString(),
    }
    set((state) => ({
      messagesByConv: {
        ...state.messagesByConv,
        [activeConversationId]: [...(state.messagesByConv[activeConversationId] ?? []), optimistic],
      },
    }))

    try {
      await messagesApi.send(activeConversationId, content, clientMsgId)
    } catch {
      // Gagal kirim — tandai pesan optimistic (biarkan di UI, minimal untuk MVP;
      // penanganan retry/failed-state adalah peningkatan Tier 2).
    }
  },

  wireWsListeners: () => {
    wsService.on<WsNewMessagePayload>('new_message', (msg) => {
      set((state) => {
        const existing = state.messagesByConv[msg.conversationId] ?? []
        // Hindari duplikat kalau pesan ini milik sendiri (sudah ada sbg optimistic
        // dgn clientMsgId yang sama) — ganti optimistic dengan versi server.
        const withoutOptimistic = existing.filter((m) => m.clientMsgId !== msg.clientMsgId || m.id === msg.id)
        const alreadyHasReal = withoutOptimistic.some((m) => m.id === msg.id)
        const next = alreadyHasReal ? withoutOptimistic : [...withoutOptimistic, msg]
        return { messagesByConv: { ...state.messagesByConv, [msg.conversationId]: next } }
      })
    })

    wsService.on<WsMessageAckPayload>('message_ack', (ack) => {
      set((state) => {
        const existing = state.messagesByConv[ack.conversationId] ?? []
        const next = existing.map((m) =>
          m.clientMsgId === ack.clientMsgId ? { ...m, id: ack.id, seq: ack.seq } : m
        )
        return { messagesByConv: { ...state.messagesByConv, [ack.conversationId]: next } }
      })
    })
  },
}))
