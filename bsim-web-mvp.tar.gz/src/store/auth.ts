import { create } from 'zustand'
import type { User } from '../types'
import { authApi, TOKEN_KEY, REFRESH_KEY } from '../services/api'
import { wsService } from '../services/ws'

interface AuthState {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  error: string | null
  login: (username: string, password: string) => Promise<void>
  logout: () => void
  restoreSession: () => void
}

function loadStoredUser(): User | null {
  const raw = localStorage.getItem('bsim_web_user')
  if (!raw) return null
  try {
    return JSON.parse(raw) as User
  } catch {
    return null
  }
}

export const useAuthStore = create<AuthState>((set) => ({
  user: loadStoredUser(),
  isAuthenticated: !!localStorage.getItem(TOKEN_KEY),
  isLoading: false,
  error: null,

  login: async (username, password) => {
    set({ isLoading: true, error: null })
    try {
      const { data } = await authApi.login(username, password)
      localStorage.setItem(TOKEN_KEY, data.accessToken)
      localStorage.setItem(REFRESH_KEY, data.refreshToken)
      localStorage.setItem('bsim_web_user', JSON.stringify(data.user))
      set({ user: data.user, isAuthenticated: true, isLoading: false })
      wsService.connect()
    } catch (err: any) {
      const message = err?.response?.data?.error ?? 'Login gagal — periksa username/password'
      set({ isLoading: false, error: typeof message === 'string' ? message : 'Login gagal' })
      throw err
    }
  },

  logout: () => {
    authApi.logout()
    localStorage.removeItem(TOKEN_KEY)
    localStorage.removeItem(REFRESH_KEY)
    localStorage.removeItem('bsim_web_user')
    wsService.disconnect()
    set({ user: null, isAuthenticated: false })
  },

  restoreSession: () => {
    const token = localStorage.getItem(TOKEN_KEY)
    const user = loadStoredUser()
    if (token && user) {
      set({ user, isAuthenticated: true })
      wsService.connect()
    }
  },
}))

window.addEventListener('bsi:logout', () => {
  useAuthStore.getState().logout()
})
