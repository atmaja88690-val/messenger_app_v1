import axios, { AxiosInstance, InternalAxiosRequestConfig } from 'axios'
import type { LoginResponse, AuthTokens, Conversation, Message } from '../types'

// Same-origin selalu — Apache (bsichat-proxy.conf) sudah forward /api ke backend.
// Tidak perlu split DEV/PROD seperti versi Electron karena web ini SELALU
// diakses lewat chat.bsilongevity.com, tidak pernah localhost langsung.
export const API_URL = '/api'
export const TOKEN_KEY = 'bsim_web_access_token'
export const REFRESH_KEY = 'bsim_web_refresh_token'

const api: AxiosInstance = axios.create({
  baseURL: API_URL,
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' },
})

api.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const token = localStorage.getItem(TOKEN_KEY)
  if (token && config.headers) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

function hardLogout() {
  localStorage.removeItem(TOKEN_KEY)
  localStorage.removeItem(REFRESH_KEY)
  window.dispatchEvent(new Event('bsi:logout'))
}

// Refresh-on-401: sederhana (tanpa proactive scheduler seperti versi Electron —
// cukup untuk MVP demo; kalau access token expire di tengah sesi, request
// berikutnya otomatis refresh sekali lalu retry).
let isRefreshing = false
let queue: Array<(token: string | null) => void> = []

api.interceptors.response.use(
  (res) => res,
  async (error) => {
    const original = error.config
    const isAuthEndpoint = original?.url?.includes('/auth/refresh') || original?.url?.includes('/auth/logout')
    if (error.response?.status !== 401 || original._retry || isAuthEndpoint) {
      return Promise.reject(error)
    }
    const storedRefresh = localStorage.getItem(REFRESH_KEY)
    if (!storedRefresh) {
      hardLogout()
      return Promise.reject(error)
    }
    original._retry = true

    if (isRefreshing) {
      return new Promise((resolve, reject) => {
        queue.push((token) => {
          if (!token) return reject(error)
          original.headers.Authorization = `Bearer ${token}`
          resolve(api(original))
        })
      })
    }

    isRefreshing = true
    try {
      const { data } = await axios.post<AuthTokens>(`${API_URL}/auth/refresh`, { refreshToken: storedRefresh })
      localStorage.setItem(TOKEN_KEY, data.accessToken)
      localStorage.setItem(REFRESH_KEY, data.refreshToken)
      queue.forEach((cb) => cb(data.accessToken))
      queue = []
      original.headers.Authorization = `Bearer ${data.accessToken}`
      return api(original)
    } catch (err) {
      queue.forEach((cb) => cb(null))
      queue = []
      hardLogout()
      return Promise.reject(err)
    } finally {
      isRefreshing = false
    }
  }
)

export const authApi = {
  login: (username: string, password: string) =>
    api.post<LoginResponse>('/auth/login', { username, password }),
  logout: () =>
    api.post('/auth/logout').catch(() => {}),
}

export const conversationsApi = {
  list: () => api.get<{ conversations: Conversation[] }>('/conversations'),
}

export const messagesApi = {
  list: (convId: string, before?: string) =>
    api.get<{ messages: Message[] }>(`/messages/${convId}`, { params: before ? { before } : {} }),
  send: (convId: string, content: string, clientMsgId: string) =>
    api.post<{ message: Message }>(`/messages/${convId}`, { content, clientMsgId, type: 'TEXT' }),
}

export default api
