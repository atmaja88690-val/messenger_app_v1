import type { WsEvent, WsEventType } from '../types'
import { TOKEN_KEY } from './api'

type WsHandler<T = unknown> = (payload: T) => void

const PING_INTERVAL_MS = 30_000

// wss:// kalau halaman dibuka lewat https (selalu demikian di chat.bsilongevity.com),
// ws:// kalau tidak. Same-origin, path /ws sudah di-proxy Apache ke backend.
function buildWsUrl(): string {
  const proto = location.protocol === 'https:' ? 'wss:' : 'ws:'
  const token = localStorage.getItem(TOKEN_KEY)
  return `${proto}//${location.host}/ws?token=${token ?? ''}`
}

class WsService {
  private ws: WebSocket | null = null
  private handlers = new Map<WsEventType, Set<WsHandler>>()
  private pingInterval: ReturnType<typeof setInterval> | null = null
  private reconnectTimeout: ReturnType<typeof setTimeout> | null = null
  private shouldReconnect = true
  private reconnectDelay = 3000

  connect() {
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) return
    const token = localStorage.getItem(TOKEN_KEY)
    if (!token) return

    this.shouldReconnect = true
    this.ws = new WebSocket(buildWsUrl())

    this.ws.onopen = () => {
      this.reconnectDelay = 3000
      this.startPing()
    }

    this.ws.onmessage = (e) => {
      try {
        const event: WsEvent = JSON.parse(e.data)
        const set = this.handlers.get(event.type as WsEventType)
        if (set) set.forEach((fn) => fn(event.payload))
      } catch {
        console.warn('[WS] Invalid message', e.data)
      }
    }

    this.ws.onerror = (e) => console.error('[WS] Error', e)

    this.ws.onclose = () => {
      this.stopPing()
      this.ws = null
      if (this.shouldReconnect) {
        this.reconnectDelay = Math.min(this.reconnectDelay * 2, 30_000)
        this.reconnectTimeout = setTimeout(() => this.connect(), this.reconnectDelay)
      }
    }
  }

  disconnect() {
    this.shouldReconnect = false
    this.stopPing()
    if (this.reconnectTimeout) clearTimeout(this.reconnectTimeout)
    this.ws?.close()
    this.ws = null
  }

  markRead(conversationId: string, seq: string | number) {
    this.send('mark_read', { conversationId, seq: String(seq) })
  }

  send(type: string, payload: unknown = {}) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type, payload }))
    }
  }

  on<T = unknown>(event: WsEventType, handler: WsHandler<T>) {
    if (!this.handlers.has(event)) this.handlers.set(event, new Set())
    this.handlers.get(event)!.add(handler as WsHandler)
  }

  off<T = unknown>(event: WsEventType, handler: WsHandler<T>) {
    this.handlers.get(event)?.delete(handler as WsHandler)
  }

  private startPing() {
    this.stopPing()
    this.pingInterval = setInterval(() => this.send('ping', {}), PING_INTERVAL_MS)
  }

  private stopPing() {
    if (this.pingInterval) {
      clearInterval(this.pingInterval)
      this.pingInterval = null
    }
  }
}

export const wsService = new WsService()
