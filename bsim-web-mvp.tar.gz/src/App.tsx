import { useEffect } from 'react'
import { useAuthStore } from './store/auth'
import { useChatStore } from './store/chat'
import { LoginPage } from './components/LoginPage'
import { ConversationList } from './components/ConversationList'
import { ChatThread } from './components/ChatThread'

export function App() {
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated)
  const restoreSession = useAuthStore((s) => s.restoreSession)
  const wireWsListeners = useChatStore((s) => s.wireWsListeners)

  useEffect(() => {
    restoreSession()
    wireWsListeners()
  }, [restoreSession, wireWsListeners])

  if (!isAuthenticated) {
    return <LoginPage />
  }

  return (
    <div className="flex h-full">
      <ConversationList />
      <ChatThread />
    </div>
  )
}
