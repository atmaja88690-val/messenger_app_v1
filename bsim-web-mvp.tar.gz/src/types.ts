export type UserStatus = 'AVAILABLE' | 'AWAY' | 'DND' | 'OFFLINE'
export type AccountType = 'USER' | 'ADMIN' | 'AGENT' | 'SUPERVISOR' | 'MODERATOR'

export interface User {
  id: string
  username: string
  displayName: string
  avatarKey?: string | null
  status: UserStatus
  accountType?: AccountType
}

export interface AuthTokens {
  accessToken: string
  refreshToken: string
}
export interface LoginResponse extends AuthTokens {
  user: User
}

export type MessageType = 'TEXT' | 'IMAGE' | 'FILE' | 'AUDIO' | 'SYSTEM' | 'CALL'

export interface Message {
  id: string
  conversationId: string
  senderId: string
  sender?: User
  seq?: string | number
  clientMsgId?: string
  type: MessageType
  body?: string | null
  content: string  // selalu string (backend: msg.body ?? ""), pakai ini untuk render
  replyToId?: string | null
  editedAt?: string | null
  deletedAt?: string | null
  createdAt: string
}

export type ConvType = 'DIRECT' | 'GROUP'

export interface ConversationMember {
  userId: string
  role: 'OWNER' | 'ADMIN' | 'MEMBER'
  user: User
}

// Shape ringkas — backend hanya select field ini untuk lastMessage
// di GET /conversations (lihat conversations.routes.ts), BUKAN Message penuh.
export interface ConversationLastMessage {
  id: string
  body?: string | null
  type: MessageType
  senderId: string
  createdAt: string
  conversationId: string
}

export interface Conversation {
  id: string
  type: ConvType
  title?: string | null
  avatarKey?: string | null
  lastMessageAt?: string | null
  lastReadSeq?: string
  lastMessage?: ConversationLastMessage | null
  members: ConversationMember[]
}

export type WsEventType =
  | 'connected' | 'new_message' | 'message_ack' | 'typing' | 'presence' | 'pong' | 'receipt' | 'error'

export interface WsEvent<T = unknown> {
  type: WsEventType
  payload: T
}
export interface WsNewMessagePayload extends Message {}
export interface WsMessageAckPayload {
  clientMsgId: string
  id: string
  seq: string
  conversationId: string
}
export interface WsPresencePayload {
  userId: string
  status: UserStatus
}
