import { useEffect } from 'react'
import { useChatStore } from '../store/chat'
import { useAuthStore } from '../store/auth'
import type { Conversation } from '../types'

function conversationLabel(conv: Conversation, myUserId?: string): string {
  if (conv.type === 'GROUP') return conv.title ?? 'Group'
  const other = conv.members.find((m) => m.userId !== myUserId)
  return other?.user.displayName ?? conv.title ?? 'Percakapan'
}

export function ConversationList() {
  const conversations = useChatStore((s) => s.conversations)
  const loadConversations = useChatStore((s) => s.loadConversations)
  const openConversation = useChatStore((s) => s.openConversation)
  const activeConversationId = useChatStore((s) => s.activeConversationId)
  const user = useAuthStore((s) => s.user)
  const logout = useAuthStore((s) => s.logout)

  useEffect(() => {
    loadConversations()
  }, [loadConversations])

  return (
    <div className="flex h-full w-80 flex-col border-r border-gray-800 bg-[#18181b]">
      <div className="flex items-center justify-between border-b border-gray-800 p-4">
        <div>
          <p className="font-medium text-white">{user?.displayName}</p>
          <p className="text-xs text-gray-500">@{user?.username}</p>
        </div>
        <button
          onClick={logout}
          className="rounded px-2 py-1 text-xs text-gray-400 hover:bg-gray-800 hover:text-white"
        >
          Keluar
        </button>
      </div>

      <div className="flex-1 overflow-y-auto">
        {conversations.length === 0 && (
          <p className="p-4 text-sm text-gray-500">Belum ada percakapan.</p>
        )}
        {conversations.map((conv) => (
          <button
            key={conv.id}
            onClick={() => openConversation(conv.id)}
            className={`block w-full border-b border-gray-800/50 px-4 py-3 text-left hover:bg-gray-800/60 ${
              activeConversationId === conv.id ? 'bg-gray-800' : ''
            }`}
          >
            <p className="truncate font-medium text-white">{conversationLabel(conv, user?.id)}</p>
            <p className="truncate text-sm text-gray-500">
              {conv.lastMessage?.body ?? 'Belum ada pesan'}
            </p>
          </button>
        ))}
      </div>
    </div>
  )
}
