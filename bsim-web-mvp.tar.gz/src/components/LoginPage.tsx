import { useState, FormEvent } from 'react'
import { useAuthStore } from '../store/auth'

export function LoginPage() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const login = useAuthStore((s) => s.login)
  const isLoading = useAuthStore((s) => s.isLoading)
  const error = useAuthStore((s) => s.error)

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    try {
      await login(username, password)
    } catch {
      // error sudah di-set di store, cukup cegah unhandled rejection di sini
    }
  }

  return (
    <div className="flex h-full items-center justify-center bg-[#1b1b1f]">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-sm rounded-xl bg-[#222222] p-8 shadow-lg"
      >
        <h1 className="mb-6 text-center text-xl font-semibold text-white">BSI Messenger — Web</h1>

        <label className="mb-1 block text-sm text-gray-300">Username</label>
        <input
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          className="mb-4 w-full rounded-md bg-[#32363f] px-3 py-2 text-white outline-none focus:ring-2 focus:ring-blue-500"
          autoFocus
          required
        />

        <label className="mb-1 block text-sm text-gray-300">Password</label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="mb-4 w-full rounded-md bg-[#32363f] px-3 py-2 text-white outline-none focus:ring-2 focus:ring-blue-500"
          required
        />

        {error && <p className="mb-4 text-sm text-red-400">{error}</p>}

        <button
          type="submit"
          disabled={isLoading}
          className="w-full rounded-md bg-blue-600 py-2 font-medium text-white hover:bg-blue-500 disabled:opacity-50"
        >
          {isLoading ? 'Masuk...' : 'Masuk'}
        </button>
      </form>
    </div>
  )
}
