import { useEffect, useRef, useState, FormEvent } from 'react'
import { useChatStore } from '../store/chat'
import { useAuthStore } from '../store/auth'
import type { Conversation } from '../types'

function conversationLabel(conv: Conversation | undefined, myUserId?: string): string {
  if (!conv) return ''
  if (conv.type === 'GROUP') return conv.title ?? 'Group'
  const other = conv.members.find((m) => m.userId !== myUserId)
  return other?.user.displayName ?? conv.title ?? 'Percakapan'
}

export function ChatThread() {
  const activeConversationId = useChatStore((s) => s.activeConversationId)
  const conversations = useChatStore((s) => s.conversations)
  const messagesByConv = useChatStore((s) => s.messagesByConv)
  const sendMessage = useChatStore((s) => s.sendMessage)
  const isLoadingMessages = useChatStore((s) => s.isLoadingMessages)
  const user = useAuthStore((s) => s.user)
  const [draft, setDraft] = useState('')
  const bottomRef = useRef<HTMLDivElement>(null)

  const conv = conversations.find((c) => c.id === activeConversationId)
  const messages = activeConversationId ? messagesByConv[activeConversationId] ?? [] : []

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages.length])

  if (!activeConversationId) {
    return (
      <div className="flex h-full flex-1 items-center justify-center text-gray-500">
        Pilih percakapan untuk mulai
      </div>
    )
  }

  function handleSubmit(e: FormEvent) {
    e.preventDefault()
    if (!draft.trim()) return
    sendMessage(draft)
    setDraft('')
  }

  return (
    <div className="flex h-full flex-1 flex-col bg-[#0f1115]">
      <div className="border-b border-gray-800 p-4">
        <p className="font-medium text-white">{conversationLabel(conv, user?.id)}</p>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        {isLoadingMessages && <p className="text-sm text-gray-500">Memuat pesan...</p>}
        {messages.map((msg) => {
          const isMine = msg.senderId === user?.id || msg.senderId === 'me'
          return (
            <div key={msg.id} className={`mb-2 flex ${isMine ? 'justify-end' : 'justify-start'}`}>
              <div
                className={`max-w-[70%] rounded-lg px-3 py-2 text-sm ${
                  isMine ? 'bg-green-700 text-white' : 'bg-gray-700 text-white'
                }`}
              >
                <p>{msg.content}</p>
                <p className="mt-1 text-right text-[10px] opacity-60">
                  {new Date(msg.createdAt).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
          )
        })}
        <div ref={bottomRef} />
      </div>

      <form onSubmit={handleSubmit} className="flex gap-2 border-t border-gray-800 p-4">
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder="Ketik pesan..."
          className="flex-1 rounded-md bg-[#22252b] px-3 py-2 text-white outline-none focus:ring-2 focus:ring-blue-500"
        />
        <button
          type="submit"
          className="rounded-md bg-blue-600 px-4 py-2 font-medium text-white hover:bg-blue-500"
        >
          Kirim
        </button>
      </form>
    </div>
  )
}
